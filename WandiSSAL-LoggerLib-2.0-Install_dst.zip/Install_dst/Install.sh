#!/bin/bash
#
# Refer to the REAME file for description about this Install.sh script.
#
cat ./README
echo ">>>>> Start installation..."
read -r -p "Confirm to continue [y/n]: " CONFIRM
if [ "$CONFIRM" != "y" ]; then
	echo ">>>>> Aborting install"
	exit 1;
else
	echo ">>>>> Your confirmation is -> $CONFIRM"
fi
# Prompt the user for the target install directory.
read -r -p "Enter the install directory full path: " LOGGER_HOME_PATH
export LOGGER_HOME_PATH=$LOGGER_HOME_PATH/WandiSSAL-2.0
echo ">>>>> Install directory is LOGGER_HOME_PATH=$LOGGER_HOME_PATH"

# Create target install directory
if [ ! -d "$LOGGER_HOME_PATH" ]; then
    echo ">>>>> Directory $LOGGER_HOME_PATH does not exist."
    mkdir -p "$LOGGER_HOME_PATH/" || { echo ">>>>> Failed to create directory"; exit 1; }
fi

# Allow the user to confirm the target install directory is accurately created
echo ">>>>> Create install directory: $LOGGER_HOME_PATH"
echo -e "\n"
read -r -p "Confirm directory was accurately created [y/n]: " CONFIRM
if [ "$CONFIRM" != "y" ]; then
	echo ">>>>> Aborting install"
	exit 1;
else
	echo ">>>>> Your confirmation is -> $CONFIRM"
fi
echo ">>>>> Create subdirectories in directory $LOGGER_HOME_PATH"
# Create all subdirectories
mkdir -p "$LOGGER_HOME_PATH/"
mkdir -p "$LOGGER_HOME_PATH/LoggerOutput"
mkdir -p "$LOGGER_HOME_PATH/LoggerSecureVault"
mkdir -p "$LOGGER_HOME_PATH/LoggerLib"
mkdir -p "$LOGGER_HOME_PATH/user_application"
ls -R $LOGGER_HOME_PATH
echo -e "\n"
read -r -p "Confirm to continue [y/n]: " CONFIRM
if [ "$CONFIRM" != "y" ]; then
	echo ">>>>> Aborting install"
	exit 1;
else
	echo ">>>>> Your confirmation is -> $CONFIRM"
fi
#
# Copy appropriate files to subdirectories
echo ">>>>> Copy files to subdirectories in $LOGGER_HOME_PATH..."
cp WandiSSAL-LoggerLib-2.0.a $LOGGER_HOME_PATH/LoggerLib/.
cp WandiSSAL-LoggerLib-2.0.h $LOGGER_HOME_PATH/LoggerLib/.
cp LoggerMessageDefines.txt $LOGGER_HOME_PATH/LoggerSecureVault/.
cp WandiSSAL-examples.c $LOGGER_HOME_PATH/user_application/.
cp Makefile $LOGGER_HOME_PATH/user_application/.
ls -R $LOGGER_HOME_PATH/*
#
echo -e "\n"
read -r -p "Confirm to continue [y/n]: " CONFIRM
if [ "$CONFIRM" != "y" ]; then
	echo ">>>>> Aborting install"
	exit 1;
else
	echo ">>>>> Your confirmation is -> $CONFIRM"
fi
# make WandiSSAL-example user application
cd $LOGGER_HOME_PATH/user_application
echo ">>>>> Compile WandiSSAL-example.c in $LOGGER_HOME_PATH/user_application"
make all
#
echo ">>>>> Add LOGGER_HOME_PATH to example_app.sh script"
echo ">>>>> Add ./WandiSSAL-example application to example_app.sh script"
cat << EOF >example_app.sh
export LOGGER_HOME_PATH=$LOGGER_HOME_PATH/
echo "Application using LOGGER_HOME_PATH: $LOGGER_HOME_PATH"
./WandiSSAL-examples
EOF
chmod 777 $LOGGER_HOME_PATH/user_application/example_app.sh
#
echo ">>>>> List compile directory:"
# List the target installed directories and files
ls -lrt $LOGGER_HOME_PATH/user_application
#
echo -e "\nTo execute application WandiSSAL-example and view output file:"
echo -e "Go to $LOGGER_HOME_PATH/user_application directory."
echo "Run ./example_app.sh to execute WandiSSAL-examples.c application program."
echo -e "Go to $LOGGER_HOME_PATH/LoggerOutput directory to view output files.\n"
#
echo -e ">>>>> Installation complete!\n"
