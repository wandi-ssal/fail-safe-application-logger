#!/bin/bash
#
# Refer to the REAME file for description about this Install.sh script.
#
cat ./README
echo ">>>>> Start installation..."
read -r -p "Confirm to continue [y/n]: " CONFIRM
if [ "$CONFIRM" != "y" ]; then
	echo ">>>>> Aborting install"
	exit 1;
else
	echo ">>>>> Your confirmation is -> $CONFIRM"
fi
# Prompt the user for the target install directory.
LOGGER_HOME_PATH=`pwd`
export LOGGER_HOME_PATH=$LOGGER_HOME_PATH
echo ">>>>> Install directory is LOGGER_HOME_PATH=$LOGGER_HOME_PATH"
echo ">>>>> Add LOGGER_HOME_PATH to example_app.sh script"
echo ">>>>> Add ./WandiSSAL-example application to example_app.sh script"
cat << EOF >user_application/example_app.sh
export LOGGER_HOME_PATH=$LOGGER_HOME_PATH/
echo "Application using LOGGER_HOME_PATH: $LOGGER_HOME_PATH"
./WandiSSAL-examples
EOF
chmod 777 $LOGGER_HOME_PATH/user_application/example_app.sh
#
echo -e "\nTo compile application WandiSSAL-example.c, go to $LOGGER_HOME_PATH/user_application directory."
echo -e "\nmake all"
echo -e "\nTo execute application WandiSSAL-example"
echo -e "\n ./example_app.sh."
echo -e "\nTo view output file, go to $LOGGER_HOME_PATH/LoggerOutput directory.\n"
echo ">>>>> Installation complete!\n"
