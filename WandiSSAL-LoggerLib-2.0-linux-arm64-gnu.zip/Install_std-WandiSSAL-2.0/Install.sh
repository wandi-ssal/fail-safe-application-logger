#!/bin/bash
#
# Refer to the REAME file for description about this Install.sh script.
#
cat ./README
echo ">>>>> Start installation..."
read -r -p "Confirm to continue [y/n]: " CONFIRM
if [ "$CONFIRM" != "y" ]; then
	echo ">>>>> Aborting install"
	exit 1;
else
	echo ">>>>> Your confirmation is -> $CONFIRM"
fi
# Prompt the user for the target install directory.
LOGGER_HOME_PATH=`pwd`
export LOGGER_HOME_PATH=$LOGGER_HOME_PATH
echo ">>>>> Install directory is LOGGER_HOME_PATH=$LOGGER_HOME_PATH"
echo ">>>>> Add LOGGER_HOME_PATH to simple_example.sh script"
echo ">>>>> Add ./WandiSSAL-simple-example application to simple_example.sh script"
cat << EOF >user_application/simple_example.sh
export LOGGER_HOME_PATH=$LOGGER_HOME_PATH/
echo "Application using LOGGER_HOME_PATH: $LOGGER_HOME_PATH"
./WandiSSAL-simple-example
EOF
chmod 700 $LOGGER_HOME_PATH/user_application/simple_example.sh
#
export LOGGER_HOME_PATH=$LOGGER_HOME_PATH
echo ">>>>> Install directory is LOGGER_HOME_PATH=$LOGGER_HOME_PATH"
echo ">>>>> Add LOGGER_HOME_PATH to bound_example.sh script"
echo ">>>>> Add ./WandiSSAL-bound-example application to bound_example.sh script"
cat << EOF >user_application/bound_example.sh
export LOGGER_HOME_PATH=$LOGGER_HOME_PATH/
echo "Application using LOGGER_HOME_PATH: $LOGGER_HOME_PATH"
./WandiSSAL-bound-example
EOF
chmod 700 $LOGGER_HOME_PATH/user_application/bound_example.sh
#
echo -e "\nTo compile application examples, go to $LOGGER_HOME_PATH/user_application directory."
echo -e "\nmake all"
echo -e "\nTo execute application WandiSSAL-simple-example"
echo -e "\n ./simple_example.sh."
echo -e "\nTo view output file, go to $LOGGER_HOME_PATH/LoggerOutput directory.\n"
echo -e "\nTo execute application WandiSSAL-bound-example"
echo -e "\n ./bound_example.sh."
echo -e "\nTo view output file, go to $LOGGER_HOME_PATH/LoggerOutput directory.\n"
echo -e ">>>>> Installation complete!\n"
